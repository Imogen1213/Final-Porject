<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject = 'UEQ Survey Results';
    $message = '';
    foreach ($_POST as $key => $value) {
        $message .= "$key: $value\n";
    }
    $headers = 'From: webmaster@example.com';

    mail('imogensophiecassidy@gmail.com', $subject, $message, $headers);
    echo 'Form submitted successfully!';
}
?>
